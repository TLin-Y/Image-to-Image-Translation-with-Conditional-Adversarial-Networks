1. Dataset put male and female images in the 'data' folder

2. run train.py, all parameters could be user-defined in the train.py file.

3. use test.py to generate result. Put images to be tested in the 'data/test/' folder.

Here, we provide pertained epoch16:
parser.add_argument('--epoch', type=int, default=16,
                        help='Generating images with weight of epoch X')

If test another epoch, need to modify 'default=16' to 'default=number of epoch'